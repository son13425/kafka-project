import json
from confluent_kafka import Producer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.json_schema import (
    JSONSerializer,
    JSONDeserializer,
)
from confluent_kafka.serialization import (
    StringSerializer, 
    SerializationContext, 
    MessageField
)
from dataclasses import dataclass, asdict
from typing import Any, Dict
from datetime import datetime
import uuid

from core.config import settings


@dataclass
class KafkaMessage:
    """Класс объекта сообщения."""

    def __init__(self, schema_registry_config: str):
        """
        Инициализация регистра схем.
        """
        self.schema_registry_config = schema_registry_config
        self.schema_registry_client = SchemaRegistryClient(schema_registry_config)
    
    def json_serializer(self, json_schema_str: str) -> JSONSerializer:
        """Сериализация в JSON."""
        return JSONSerializer(json_schema_str, self.schema_registry_client)
    
    @classmethod
    def json_deserializer(self, json_schema_str: str) -> dict:
        """Десериализация из JSON."""
        return JSONDeserializer(json_schema_str, self.schema_registry_client)
    
    @classmethod
    def create(message_value: dict) -> dict:
        """Создание сообщения с автоматической генерацией ID и timestamp"""
        message_value['timestamp'] = datetime.now().isoformat()
        message_value['id'] = str(uuid.uuid4())
        return message_value


# Глобальный экземпляр регистра схем
schema_registry_instance: Optional[KafkaMessage] = None

def init_schema_registry(schema_registry_config: str) -> KafkaMessage:
    """Инициализация глобального регистра схем."""
    global schema_registry_instance
    if schema_registry_instance is None:
        schema_registry_instance = KafkaMessage(schema_registry_config)
    return schema_registry_instance

def get_schema_registry() -> Optional[KafkaMessage]:
    """Получение глобального регистра схем"""
    return schema_registry_instance
