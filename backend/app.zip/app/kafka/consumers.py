import json
import logging
import threading
import time
from kafka import KafkaConsumer
from kafka.errors import KafkaError
from typing import List, Optional
from .message import KafkaMessage

logger = logging.getLogger(__name__)

class BaseConsumer:
    """Базовый класс консьюмера"""
    
    def __init__(self, bootstrap_servers: str, topic: str, group_id: str):
        self.bootstrap_servers = bootstrap_servers
        self.topic = topic
        self.group_id = group_id
        self.running = False
        
    def process_message(self, message: KafkaMessage):
        """Обработка одного сообщения (должен быть переопределен)"""
        raise NotImplementedError
    
    def start(self):
        """Запуск консьюмера"""
        self.running = True
        thread = threading.Thread(target=self._consume, daemon=True)
        thread.start()
        logger.info(f"Консьюмер {self.__class__.__name__} запущен")
    
    def stop(self):
        """Остановка консьюмера"""
        self.running = False

class SingleMessageConsumer(BaseConsumer):
    """Консьюмер для обработки по одному сообщению"""
    
    def __init__(self, bootstrap_servers: str, topic: str, group_id: str):
        super().__init__(bootstrap_servers, topic, group_id)
        
        self.consumer = KafkaConsumer(
            topic,
            bootstrap_servers=bootstrap_servers,
            group_id=group_id,
            auto_offset_reset='earliest',
            enable_auto_commit=True,  # Автоматический коммит
            auto_commit_interval_ms=1000,
            key_deserializer=lambda v: v.decode('utf-8') if v else None,
            value_deserializer=lambda v: v.decode('utf-8'),
            fetch_max_wait_ms=500,  # Максимальное время ожидания данных
            fetch_min_bytes=1  # Минимальный объем данных
        )
    
    def process_message(self, message: KafkaMessage):
        """Обработка одного сообщения"""
        print(f"SingleConsumer получил сообщение: {message.msg}")
        # Здесь может быть бизнес-логика обработки
        # При ошибке - логируем и продолжаем
        try:
            # Пример обработки
            processed_data = message.msg.upper()
            print(f"Обработано: {processed_data}")
        except Exception as e:
            logger.error(f"Ошибка обработки сообщения: {e}")
            print(f"Ошибка обработки: {e}")
    
    def _consume(self):
        """Основной цикл потребления сообщений"""
        while self.running:
            try:
                # Получение сообщений (poll возвращает batch, но мы обрабатываем по одному)
                message_batch = self.consumer.poll(timeout_ms=1000)
                
                for topic_partition, messages in message_batch.items():
                    for message in messages:
                        try:
                            # Десериализация
                            kafka_msg = KafkaMessage.from_json(message.value)
                            
                            # Вывод в консоль
                            print(f"SingleConsumer: Получено сообщение ID={kafka_msg.message_id}")
                            
                            # Обработка
                            self.process_message(kafka_msg)
                            
                        except Exception as e:
                            logger.error(f"Ошибка десериализации/обработки: {e}")
                            print(f"Ошибка: {e}")
                            continue
                
            except KafkaError as e:
                logger.error(f"Ошибка Kafka: {e}")
                print(f"Ошибка Kafka: {e}")
                time.sleep(1)  # Пауза при ошибке
                
            except Exception as e:
                logger.error(f"Неожиданная ошибка: {e}")
                print(f"Неожиданная ошибка: {e}")
                time.sleep(1)
    
    def stop(self):
        """Остановка консьюмера"""
        super().stop()
        self.consumer.close()

class BatchMessageConsumer(BaseConsumer):
    """Консьюмер для обработки пачек сообщений"""
    
    def __init__(self, bootstrap_servers: str, topic: str, group_id: str, 
                 batch_size: int = 10):
        super().__init__(bootstrap_servers, topic, group_id)
        self.batch_size = batch_size
        
        self.consumer = KafkaConsumer(
            topic,
            bootstrap_servers=bootstrap_servers,
            group_id=group_id,
            auto_offset_reset='earliest',
            enable_auto_commit=False,  # Ручной коммит
            key_deserializer=lambda v: v.decode('utf-8') if v else None,
            value_deserializer=lambda v: v.decode('utf-8'),
            fetch_max_wait_ms=5000,  # Ждем до 5 секунд для накопления данных
            fetch_min_bytes=1024,  # Минимум 1KB для накопления
            max_poll_records=batch_size  # Максимальное количество записей за poll
        )
    
    def process_batch(self, messages: List[KafkaMessage]):
        """Обработка пачки сообщений"""
        print(f"BatchConsumer обрабатывает пачку из {len(messages)} сообщений")
        
        for message in messages:
            try:
                print(f"Обработка сообщения из пачки: {message.msg[:50]}...")
                # Бизнес-логика обработки
                processed_data = message.msg.lower()
                print(f"Обработано: {processed_data[:50]}...")
                
            except Exception as e:
                logger.error(f"Ошибка обработки сообщения в пачке: {e}")
                print(f"Ошибка обработки в пачке: {e}")
                continue
    
    def _consume(self):
        """Основной цикл потребления сообщений пачками"""
        while self.running:
            try:
                # Получение пачки сообщений
                message_batch = self.consumer.poll(timeout_ms=5000)
                
                if not message_batch:
                    continue
                
                messages_to_process = []
                
                # Сбор сообщений из всех партиций
                for topic_partition, messages in message_batch.items():
                    for message in messages:
                        try:
                            kafka_msg = KafkaMessage.from_json(message.value)
                            messages_to_process.append(kafka_msg)
                            print(f"BatchConsumer: Добавлено в пачку сообщение ID={kafka_msg.message_id}")
                            
                        except Exception as e:
                            logger.error(f"Ошибка десериализации: {e}")
                            print(f"Ошибка десериализации: {e}")
                            continue
                
                # Обработка пачки
                if messages_to_process:
                    print(f"Обработка пачки из {len(messages_to_process)} сообщений")
                    self.process_batch(messages_to_process)
                    
                    # Ручной коммит после обработки всей пачки
                    self.consumer.commit(asynchronous=False)
                    print(f"Коммит оффсетов после обработки пачки")
                
            except KafkaError as e:
                logger.error(f"Ошибка Kafka: {e}")
                print(f"Ошибка Kafka: {e}")
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"Неожиданная ошибка: {e}")
                print(f"Неожиданная ошибка: {e}")
                time.sleep(1)
    
    def stop(self):
        """Остановка консьюмера"""
        super().stop()
        self.consumer.close()

# Глобальные экземпляры консьюмеров
single_consumer_instance: Optional[SingleMessageConsumer] = None
batch_consumer_instance: Optional[BatchMessageConsumer] = None

def init_consumers(bootstrap_servers: str, topic: str, 
                   single_group_id: str, batch_group_id: str):
    """Инициализация консьюмеров"""
    global single_consumer_instance, batch_consumer_instance
    
    # SingleMessageConsumer с уникальным group_id
    if single_consumer_instance is None:
        single_consumer_instance = SingleMessageConsumer(
            bootstrap_servers=bootstrap_servers,
            topic=topic,
            group_id=single_group_id
        )
    
    # BatchMessageConsumer с уникальным group_id
    if batch_consumer_instance is None:
        batch_consumer_instance = BatchMessageConsumer(
            bootstrap_servers=bootstrap_servers,
            topic=topic,
            group_id=batch_group_id,
            batch_size=10
        )
    
    return single_consumer_instance, batch_consumer_instance

def start_consumers():
    """Запуск консьюмеров"""
    if single_consumer_instance:
        single_consumer_instance.start()
    if batch_consumer_instance:
        batch_consumer_instance.start()

def stop_consumers():
    """Остановка консьюмеров"""
    if single_consumer_instance:
        single_consumer_instance.stop()
    if batch_consumer_instance:
        batch_consumer_instance.stop()