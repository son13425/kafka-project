import json
import logging
from confluent_kafka.serialization import (
    StringSerializer, 
    SerializationContext, 
    MessageField
)
from kafka import KafkaProducer
from kafka.errors import KafkaError
from typing import Optional
from .message import KafkaMessage

from app.kafka.message import get_schema_registry
from app.kafka.schemas import json_schema_str

logger = logging.getLogger(__name__)

class MessageProducer:
    def __init__(self, bootstrap_servers: str, topic: str):
        """
        Инициализация продюсера с гарантией At Least Once
        
        Параметры:
        - acks='all': ждем подтверждения от всех синхронных реплик
        - retries=3: 3 попытки повторной отправки при ошибке
        - max_in_flight_requests_per_connection=1: гарантия порядка сообщений
        """
        self.bootstrap_servers = bootstrap_servers
        self.topic = topic
        self.key_serializer = StringSerializer('utf_8')
        self.schema_registry = get_schema_registry()
        self.value_serializer = self.schema_registry.json_serializer(json_schema_str)
        
        self.producer = KafkaProducer(
            bootstrap_servers=bootstrap_servers,
            acks='all',  # Ждем подтверждения от всех in-sync реплик
            retries=3,  # 3 попытки повторной отправки
            max_in_flight_requests_per_connection=1,  # Гарантия порядка
            key_serializer=self.key_serializer("msg_key", SerializationContext(topic, MessageField.VALUE)),
            value_serializer=self.value_serializer(message_value, SerializationContext(topic, MessageField.VALUE)),
            compression_type='gzip'
        )
    
    def send_message(self, key: str, message: str) -> bool:
        """
        Отправка сообщения в Kafka
        
        Returns:
            bool: True если сообщение успешно отправлено
        """
        try:
            # Создаем структурированное сообщение
            kafka_msg = self.schema_registry.create(msg=message)
            
            # Выводим отправляемое сообщение в консоль
            print(f"Отправка сообщения в Kafka: {kafka_msg}")
            
            # Отправляем в Kafka
            future = self.producer.send(
                topic=self.topic,
                key=key,
                value=kafka_msg
            )
            
            # Ждем подтверждения (блокирующий вызов)
            record_metadata = future.get(timeout=10)
            
            logger.info(f"Сообщение отправлено в топик {record_metadata.topic}, "
                       f"партиция {record_metadata.partition}, "
                       f"оффсет {record_metadata.offset}")
            
            return True
            
        except KafkaError as e:
            logger.error(f"Ошибка при отправке сообщения в Kafka: {e}")
            print(f"Ошибка Kafka: {e}")
            return False
            
        except Exception as e:
            logger.error(f"Неожиданная ошибка при отправке сообщения: {e}")
            print(f"Ошибка: {e}")
            return False
    
    def close(self):
        """Закрытие продюсера"""
        try:
            self.producer.flush()
            self.producer.close()
        except Exception as e:
            logger.error(f"Ошибка при закрытии продюсера: {e}")

# Глобальный экземпляр продюсера
producer_instance: Optional[MessageProducer] = None

def init_producer(bootstrap_servers: str, topic: str) -> MessageProducer:
    """Инициализация глобального продюсера"""
    global producer_instance
    if producer_instance is None:
        producer_instance = MessageProducer(bootstrap_servers, topic)
    return producer_instance

def get_producer() -> Optional[MessageProducer]:
    """Получение глобального продюсера"""
    return producer_instance
