import uvicorn
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import ORJSONResponse
from api.routers import main_router
from core.config import settings
from app.kafka.message import init_schema_registry, get_schema_registry
from app.kafka.producer import init_producer, get_producer
from app.kafka.consumers import init_consumers, start_consumers, stop_consumers


logging.basicConfig(
    level=settings.log_level,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


logger = logging.getLogger(__name__)


app = FastAPI(
    title=settings.name,
    default_response_class=ORJSONResponse,
    docs_url='/api/openapi',
    openapi_url='/api/openapi.json'
)


app.include_router(main_router, prefix='/api')


app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['GET', 'POST', 'OPTIONS'],
    allow_headers=[
        'Content-Type',
        'Access-Control-Allow-Headers',
        'Access-Control-Allow-Origin'
    ],
)


@app.on_event('startup')
async def startup_event():
    logger.info('Запуск Kafka')
    try:
        init_producer(
            bootstrap_servers=settings.kafka_bootstrap_servers,
            topic=settings.kafka_topic
        )
        logger.info('Kafka продюсер инициализирован')
    except Exception as e:
        logger.error(f'Ошибка инициализации продюсера: {e}')
    try:
        init_consumers(
            bootstrap_servers=settings.kafka_bootstrap_servers,
            topic=settings.kafka_topic,
            single_group_id=settings.single_consumer_group_id,
            batch_group_id=settings.batch_consumer_group_id
        )
        logger.info('Kafka консьюмеры инициализированы')
        start_consumers()
        logger.info('Kafka консьюмеры запущены')
    except Exception as e:
        logger.error(f'Ошибка инициализации консьюмеров: {e}')
    try:
        init_schema_registry(
            schema_registry_config=settings.kafka_schemaregistry_url
        )
        logger.info('Kafka регистр схем инициализирован')
    except Exception as e:
        logger.error(f'Ошибка инициализации регистра схем: {e}')


@app.on_event('shutdown')
async def shutdown_event():
    logger.info('Завершение приложения Kafka')
    stop_consumers()
    producer = get_producer()
    if producer:
        producer.close()
    schema_registry = get_schema_registry()
    if schema_registry:
        schema_registry.close()


if __name__ == '__main__':
    uvicorn.run(
        'main:app',
        host=settings.host,
        port=settings.port,
        reload=True
    )